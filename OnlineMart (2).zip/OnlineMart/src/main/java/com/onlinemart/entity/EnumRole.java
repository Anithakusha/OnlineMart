package com.onlinemart.entity;

public enum EnumRole 
{
	ROLE_ADMIN,
	ROLE_USER	
}
