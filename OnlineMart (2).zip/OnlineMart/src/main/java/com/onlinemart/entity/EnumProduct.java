package com.onlinemart.entity;

public enum EnumProduct 
{
	Home_Applicance,
	Electronic_Appliance,
	Grocery,//Snacks,Fruits,Vegetables,Kitchen items
	Cosmetics,
	Clothes,
	FootWear,
	Toys,
	Personal_Care,
	Jewellery,
	Watches
}
