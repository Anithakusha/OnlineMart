package com.onlinemart;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class OnlineMartApplicationTests {

	@Test
	void contextLoads() {
	}

}
